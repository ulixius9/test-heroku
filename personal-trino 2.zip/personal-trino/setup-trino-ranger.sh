#!/bin/bash

# Script to set up Trino with direct Ranger integration using simple authentication

set -e

# Ranger credentials
RANGER_USERNAME="admin"
RANGER_PASSWORD="rangerR0cks!"
RANGER_URL="http://localhost:6080"

echo "Setting up Trino with direct Ranger integration..."

# Check if Ranger is accessible
echo "Checking Ranger availability..."
if ! curl -s -f -u ${RANGER_USERNAME}:${RANGER_PASSWORD} ${RANGER_URL}/service/public/v2/api/service > /dev/null; then
    echo "❌ Ranger is not accessible at ${RANGER_URL}"
    echo "Please ensure Ranger is running first."
    echo "You can check Ranger status at: ${RANGER_URL}"
    exit 1
fi

echo "✅ Ranger is accessible"

# Delete existing Trino service if it exists (to avoid conflicts)
echo "Checking for existing Trino service..."
if curl -s -u ${RANGER_USERNAME}:${RANGER_PASSWORD} "${RANGER_URL}/service/public/v2/api/service/name/trino" | grep -q '"name":"trino"'; then
    echo "Deleting existing Trino service..."
    curl -s -u ${RANGER_USERNAME}:${RANGER_PASSWORD} -X DELETE "${RANGER_URL}/service/public/v2/api/service/trino" || echo "Service deletion may have failed"
    sleep 2
fi

# Create Trino service definition in Ranger
echo "Creating Trino service in Ranger..."
curl -s -u ${RANGER_USERNAME}:${RANGER_PASSWORD} \
    -X POST \
    -H "Content-Type: application/json" \
    -d '{
        "name": "trino",
        "type": "trino",
        "description": "Trino service for authorization and tag-based masking",
        "isEnabled": true,
        "configs": {
            "username": "trino",
            "jdbc.driverClassName": "io.trino.jdbc.TrinoDriver",
            "jdbc.url": "jdbc:trino://localhost:8081"
        }
    }' \
    ${RANGER_URL}/service/public/v2/api/service

echo "✅ Trino service created in Ranger"

# Create a basic policy for the trino user
echo "Creating basic access policy for trino user..."
curl -s -u ${RANGER_USERNAME}:${RANGER_PASSWORD} \
    -X POST \
    -H "Content-Type: application/json" \
    -d '{
        "name": "trino-user-access",
        "service": "trino",
        "description": "Basic access policy for trino user",
        "isEnabled": true,
        "isAuditEnabled": true,
        "resources": {
            "catalog": {
                "values": ["*"],
                "isExcludes": false,
                "isRecursive": false
            },
            "schema": {
                "values": ["*"],
                "isExcludes": false,
                "isRecursive": false
            },
            "table": {
                "values": ["*"],
                "isExcludes": false,
                "isRecursive": false
            }
        },
        "policyItems": [
            {
                "accesses": [
                    {"type": "select", "isAllowed": true},
                    {"type": "insert", "isAllowed": true},
                    {"type": "delete", "isAllowed": true},
                    {"type": "create", "isAllowed": true},
                    {"type": "drop", "isAllowed": true},
                    {"type": "alter", "isAllowed": true},
                    {"type": "show", "isAllowed": true},
                    {"type": "all", "isAllowed": true}
                ],
                "users": ["trino", "admin"],
                "groups": ["admin"],
                "conditions": [],
                "delegateAdmin": false
            }
        ]
    }' \
    ${RANGER_URL}/service/public/v2/api/policy

echo "✅ Basic access policy created"

# Create an impersonation policy
echo "Creating impersonation policy..."
curl -s -u ${RANGER_USERNAME}:${RANGER_PASSWORD} \
    -X POST \
    -H "Content-Type: application/json" \
    -d '{
        "name": "trino-impersonation",
        "service": "trino",
        "description": "Impersonation policy for trino service",
        "isEnabled": true,
        "isAuditEnabled": true,
        "resources": {
            "trinouser": {
                "values": ["*"],
                "isExcludes": false,
                "isRecursive": false
            }
        },
        "policyItems": [
            {
                "accesses": [
                    {"type": "impersonate", "isAllowed": true}
                ],
                "users": ["trino"],
                "groups": ["admin"],
                "conditions": [],
                "delegateAdmin": false
            }
        ]
    }' \
    ${RANGER_URL}/service/public/v2/api/policy

echo "✅ Impersonation policy created"

# Stop existing containers
echo "Stopping existing Trino containers..."
docker-compose down || echo "No containers to stop"

# Build and start Trino with Ranger integration
echo "Building and starting Trino with Ranger integration..."
docker-compose up --build -d

# Wait for Trino to start
echo "Waiting for Trino to start..."
sleep 30

# Test connection
echo "Testing Trino connection..."
if curl -s -f http://localhost:8081/v1/info > /dev/null; then
    echo "✅ Trino is running successfully"
else
    echo "❌ Trino failed to start. Check logs with: docker-compose logs trino"
    exit 1
fi

echo ""
echo "🎉 Setup complete!"
echo "- Trino: http://localhost:8081"
echo "- Ranger: ${RANGER_URL}"
echo "- Ranger Login: ${RANGER_USERNAME}/${RANGER_PASSWORD}"
echo ""
echo "Next steps for tag-based masking:"
echo "1. Go to Ranger Admin UI (${RANGER_URL})"
echo "2. Navigate to 'Tag Based Policies' section"
echo "3. Create tags (e.g., 'PII', 'SENSITIVE', 'CONFIDENTIAL')"
echo "4. Create tag-based masking policies"
echo "5. Associate tags with your data sources"
echo ""
echo "Test access with: trino --server localhost:8081 --user trino"
echo ""
echo "Monitor logs:"
echo "- Trino: docker-compose logs -f trino"
echo "- Ranger connectivity: docker-compose logs -f wait-for-ranger" 